library(ORE) 
ore.connect(user = "dmuser", sid = "ORCL", host = "localhost", password = "sibanjan123",port = 1521)
set.seed(999)
trainset <- read.csv("C:/Users/Admin/Dropbox/analytics_book/chapter-8/working/creditset_train.csv")
trainData <- ore.push(trainset)
fit <- ore.neural('default10yr ~ LTI + age', data = trainData,hiddenSizes = c(5L), ,activations = c("sigmoid", "linear"))
testset <- read.csv("C:/Users/Admin/Dropbox/analytics_book/chapter-8/working/creditset_test.csv")
testData <- ore.push(testset)
rownames(testData) <- testData$clientid
ans <- ore.predict(fit, newdata = testData, supplemental.cols = c("clientid","default10yr"))
res <- ore.pull(ans)
res$pred_default10yr <- round(res$pred_default10yr)
rownames(res) <- res$clientid
#results <- merge(trainData,res,by="clientid")
res
confusion.matrix <- with(res, table(default10yr, pred_default10yr))
confusion.matrix