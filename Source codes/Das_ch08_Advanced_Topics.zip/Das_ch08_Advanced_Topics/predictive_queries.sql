BEGIN
  DBMS_PREDICTIVE_ANALYTICS.EXPLAIN(
  DATA_TABLE_NAME => 'DEMO_CUST_CHURN_TAB',
  DATA_SCHEMA_NAME => 'DMUSER',
  EXPLAIN_COLUMN_NAME => 'CHURN',
  RESULT_TABLE_NAME =>'DEMO_CUST_CHURN_EXP_PRED');

END;
/
DECLARE
 v_accuracy NUMBER(30,10);
BEGIN
  DBMS_PREDICTIVE_ANALYTICS.PREDICT(
  ACCURACY => v_accuracy,
  DATA_TABLE_NAME => 'DEMO_CUST_CHURN_TAB',
  DATA_SCHEMA_NAME => 'DMUSER',
  CASE_ID_COLUMN_NAME => 'CUSTOMERID',
  TARGET_COLUMN_NAME => 'CHURN',
  RESULT_TABLE_NAME => 'DEMO_CUST_CHURN_ANALYTICS_PRED');

  dbms_output.put_line('*** Accuracy ***');
  dbms_output.put_line(' Accuracy '||v_accuracy);
END;
/
BEGIN
  dbms_predictive_analytics.profile(
  DATA_TABLE_NAME => 'DEMO_CUST_CHURN_TAB',
  data_schema_name => 'DMUSER',
  target_column_name => 'CHURN',
  result_table_name =>'DEMO_CUST_CHURN_PROF_PRED');

END;
