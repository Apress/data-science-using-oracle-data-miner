 library(ORE)
 if (!ore.is.connected()) # Check if client is already connected to R
   ore.connect("dmuser", "orcl","localhost", "sibanjan123", all=TRUE)
 airfare <- read.csv("C:/Users/Admin/Dropbox/analytics_book/chapter-6/data/airfares.csv")
 airfare_odf <- ore.push(airfare)
 oreFit <- ore.lm(Fare ~ ., data = airfare_odf)
 summary(oreFit)
 ore.predict(oreFit, airfare_odf)