set serveroutput on

ALTER TABLE DEMO_GLMR_AIRLINE_DATA ADD CUSTOMER_ID NUMBER;
/
CREATE SEQUENCE DEMO_GLMR_AIRLINE_S
START WITH 1
NOCYCLE
NOCACHE;
/
UPDATE DEMO_GLMR_AIRLINE_DATA SET CUSTOMER_ID=DEMO_GLMR_AIRLINE_S.NEXTVAL;
/

CREATE TABLE glmr_settings_demo (
  setting_name  VARCHAR2(30),
  setting_value VARCHAR2(4000));
/

-- Turn on feature selection and generation
--  
BEGIN 
-- Populate settings table
  INSERT INTO glmr_settings_demo (setting_name, setting_value) VALUES
    (dbms_data_mining.algo_name, dbms_data_mining.algo_generalized_linear_model);
  -- output row diagnostic statistics into a table named GLMC_SH_SAMPLE_DIAG  
  INSERT INTO  glmr_settings_demo (setting_name, setting_value) VALUES
    (dbms_data_mining.glms_diagnostics_table_name, 'GLMR_SH_SAMPLE_DIAG');  
  INSERT INTO  glmr_settings_demo (setting_name, setting_value) VALUES
    (dbms_data_mining.prep_auto, dbms_data_mining.prep_auto_on);  
END;
COMMIT;

BEGIN
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => 'DEMO_GLMR_MODEL',
    mining_function     => DBMS_DATA_MINING.REGRESSION,
    data_table_name     => 'DEMO_GLMR_AIRLINE_DATA',
    case_id_column_name => 'CUSTOMER_ID',
	  target_column_name  => 'FARE',
    settings_table_name => 'glmr_settings_demo'
    );
END;
/
-- Global details
SELECT *
  FROM TABLE(dbms_data_mining.get_model_details_global('DEMO_GLMR_MODEL'))
where global_detail_name in ('ADJUSTED_R_SQUARE','F_VALUE','R_SQ','AIC')
ORDER BY global_detail_name;
/
--Attribute
SELECT attribute_name ,std_error, coefficient, test_statistic,p_value,vif 
  FROM TABLE(dbms_data_mining.get_model_details_glm('DEMO_GLMR_MODEL'))

