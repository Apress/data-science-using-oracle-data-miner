BEGIN
-- Drop the R script if already present. For the first time execution sys.rqScriptDrop code has to be commented out
sys.rqScriptDrop('big_mart_mva');
-- Create the R script that would be stored in the oracle database using sys.rqScriptCreate
sys.rqScriptCreate('big_mart_mva', 'function(dat,attr1, attr2,attr3,attr4,attr5) {
library(ORE)
maverage <- function(x,n=3){filter(x,rep(1/n,n), sides=1)}
mv_fit_func <- function(column){
  tail(maverage(eval((substitute(dat[a], list(a = column)))),3),3)
}
forecast1 <- mean(mv_fit_func(attr1))
forecast2 <- mean(mv_fit_func(attr2))
forecast3 <- mean(mv_fit_func(attr3))
forecast4 <- mean(mv_fit_func(attr4))
forecast5 <- mean(mv_fit_func(attr5))
data.frame(forecast1,forecast2,forecast3,forecast4,forecast5)
}');
END;
/
COMMIT;

select to_char(add_months(to_date(max_order_date,'Mon-YY'),1),'Mon-YY') "ORDER_DATE",rgp.* from (select * from table(rqTableEval(
  cursor(select * from "Filter Columns_N$10002"),
  cursor(select 'FURNITURE' "attr1",
                'JEWELRY' "attr2",
                'FASHION_WEAR' "attr3",
				'TOYS' "attr4",
				'WATCH' "attr5",
             1 "ore.connect" from dual),
        'select 1 "FURNITURE_FORECAST",1 "JEWELRY_FORECAST",1 "MEN_CLOTHING_FORECAST",1 "TOYS",1 "WATCH" from dual',
       'big_mart_mva')) )rgp,
       (select max(ORDER_DATE) max_order_date from 
         "Filter Columns_N$10002") filter_columns_tab