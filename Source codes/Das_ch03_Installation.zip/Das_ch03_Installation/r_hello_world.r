#1. Load the  ORE library
library(ORE)
#2. Connect to the database using ore.connect(). Replace the parameters with your Database #credentials
ore.connect(user="DMUSER",sid="ORCL",host="localhost",password="sibanjan123","1521", all=TRUE)
#3. Invoke standalone ORE function using ore.doEval()
test <- ore.doEval(
function() {
"Hello World!"
}, ore.connect = TRUE);
#4. Print the result
print(test)