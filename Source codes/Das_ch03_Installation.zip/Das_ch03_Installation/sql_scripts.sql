install.packages("D:/software/ore-client-win-x86_64-1.5/client/ORE_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREbase_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREcommon_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREdm_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREeda_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREembed_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREgraphics_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREmodels_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREpredict_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/OREstats_1.5.zip")
install.packages("D:/software/ore-client-win-x86_64-1.5/client/ORExml_1.5.zip")


install.packages("D:/software/ore-supporting-win-x86_64-1.5/supporting/arules_1.1-9.zip")
install.packages("D:/software/ore-supporting-win-x86_64-1.5/supporting/Cairo_1.5-8.zip")
install.packages("D:/software/ore-supporting-win-x86_64-1.5/supporting/DBI_0.3.1.zip")
install.packages("D:/software/ore-supporting-win-x86_64-1.5/supporting/png_0.1-7.zip")
install.packages("D:/software/ore-supporting-win-x86_64-1.5/supporting/randomForest_4.6-10.zip")
install.packages("D:/software/ore-supporting-win-x86_64-1.5/supporting/ROracle_1.2-1.zip")
install.packages("D:/software/ore-supporting-win-x86_64-1.5/supporting/statmod_1.4.21.zip")



--1. Create a R script to be stored in the database's R repository identified by script name test_plsql
begin
sys.rqScriptCreate
('test_plsql','function() {"Hello World!"}');
end;
/

--2. Invoke the previosuly stored R script(test_plsql) using rqEval and return the result as an XML file 

select name, value
from table(
1rqEval
(
NULL,
'XML',
'test_plsql'));

