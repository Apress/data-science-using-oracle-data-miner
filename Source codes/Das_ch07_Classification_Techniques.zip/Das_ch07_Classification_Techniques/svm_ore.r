library(ORE)
if (!ore.is.connected()) # Check if client is already connected to R
   ore.connect("dmuser", "orcl","localhost", "sibanjan123")
ore.sync("DMUSER","HR_EMPLOYEE_ATTRITION",use.keys=TRUE)
emp_df<-ore.get("HR_EMPLOYEE_ATTRITION",schema="DMUSER")
ore_svm.mod  <- ore.odmSVM(ATTRITION ~ ., data=emp_df,"classification",kernel.function="linear")
summary(ore_svm.mod)