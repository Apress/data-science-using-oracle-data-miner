select  
       prediction(DEMO_CLASS_SVM using *) pred_value,
       prediction_probability(DEMO_CLASS_SVM using *) pred_prob,
       prediction_details(DEMO_CLASS_SVM using *) pred_details
from HR_EMPLOYEE_ATTRITION;
