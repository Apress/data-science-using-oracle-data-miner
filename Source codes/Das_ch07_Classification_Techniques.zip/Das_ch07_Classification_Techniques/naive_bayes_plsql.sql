CREATE TABLE nb_sample_priors (
  target_value      VARCHAR2(10),
  prior_probability NUMBER);
INSERT INTO nb_sample_priors VALUES ('Yes',0.65);
INSERT INTO nb_sample_priors VALUES ('No',0.35);

CREATE TABLE demo_nb_settings (
  setting_name  VARCHAR2(30),
  setting_value VARCHAR2(4000));


BEGIN  
  -- Populate settings table NB
  INSERT INTO demo_nb_settings(setting_name, setting_value) VALUES 
  (dbms_data_mining.prep_auto,dbms_data_mining.prep_auto_on);
  INSERT INTO demo_nb_settings VALUES
  (dbms_data_mining.clas_priors_table_name, 'nb_sample_priors');
END;
/
BEGIN
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => 'demo_class_nb',
    mining_function     => dbms_data_mining.classification,
    data_table_name     => 'HR_EMPLOYEE_ATTRITION',
    case_id_column_name => null,
    target_column_name  => 'attrition',
    settings_table_name => 'demo_nb_settings');
END;
/
select * from user_mining_models where model_name = 'DEMO_CLASS_NB';
SELECT setting_name, setting_value FROM user_mining_model_settings 
WHERE model_name = 'DEMO_CLASS_NB'
ORDER BY setting_name;
