set serveroutput on
CREATE TABLE demo_svm_settings (
  setting_name  VARCHAR2(30),
  setting_value VARCHAR2(4000));
/
--  
BEGIN       
  -- Populate settings table for SVM
-- Populate settings table
  INSERT INTO demo_svm_settings(setting_name, setting_value) VALUES
  (dbms_data_mining.algo_name, dbms_data_mining.algo_support_vector_machines);
  INSERT INTO demo_svm_settings (setting_name, setting_value) VALUES
  (dbms_data_mining.svms_kernel_function, dbms_data_mining.svms_linear);
  insert into demo_svm_settings (setting_name, setting_value) VALUES
  (dbms_data_mining.prep_auto, dbms_data_mining.prep_auto_on);

END;
/
BEGIN
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => 'demo_class_svm',
    mining_function     => dbms_data_mining.classification,
    data_table_name     => 'HR_EMPLOYEE_ATTRITION',
    case_id_column_name => null,
    target_column_name  => 'attrition',
    settings_table_name => 'demo_svm_settings');
END;
/
select * from user_mining_models where model_name = 'DEMO_CLASS_SVM';
SELECT setting_name, setting_value
  FROM user_mining_model_settings
 WHERE model_name = 'DEMO_GLMR_MODEL'
ORDER BY setting_name;
/
SELECT details_tab.class, attributes_tab.attribute_name aname, attributes_tab.attribute_value aval, attributes_tab.coefficient coeff
  FROM TABLE(DBMS_DATA_MINING.GET_MODEL_DETAILS_SVM('DEMO_CLASS_SVM')) details_tab,
       TABLE(details_tab.attribute_set) attributes_tab
ORDER BY details_tab.class, ABS(attributes_tab.coefficient) DESC;
