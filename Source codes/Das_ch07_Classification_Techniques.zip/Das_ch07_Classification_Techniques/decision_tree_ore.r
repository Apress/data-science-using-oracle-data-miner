library(ORE)
if (!ore.is.connected()) # Check if client is already connected to R
   ore.connect("dmuser", "orcl","localhost", "sibanjan123")
ore.sync("DMUSER","HR_EMPLOYEE_ATTRITION",use.keys=TRUE)
emp_df<-ore.get("HR_EMPLOYEE_ATTRITION",schema="DMUSER")
dt.mod  <- ore.odmDT(ATTRITION ~ ., data= emp_df)
summary(dt.mod)