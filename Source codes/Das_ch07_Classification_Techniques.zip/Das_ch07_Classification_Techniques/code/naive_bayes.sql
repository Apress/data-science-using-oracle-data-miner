library(ORE)
if (!ore.is.connected()) # Check if client is already connected to R
   ore.connect("dmuser", "orcl","localhost", "sibanjan123")
ore.sync("DMUSER","HR_EMPLOYEE_ATTRITION",use.keys=TRUE)
attrition_df<-ore.get("HR_EMPLOYEE_ATTRITION",schema="DMUSER")
# Build model
  ore.nb.mod  <- ore.odmNB(ATTRITION ~ ., attrition_df)
  summary(ore.nb.mod)
# Make predictions
  nb.res  <- predict (ore.nb.mod, attrition_df,"ATTRITION")
  with(nb.res, table(ATTRITION,PREDICTION))  # generate confusion matrix
