

CREATE TABLE demo_svm_settings (
  setting_name  VARCHAR2(30),
  setting_value VARCHAR2(4000));

 
  
BEGIN       
  -- Populate settings table for SVM
-- Populate settings table
  INSERT INTO demo_svm_settings(setting_name, setting_value) VALUES
  (dbms_data_mining.algo_name, dbms_data_mining.algo_support_vector_machines);
  INSERT INTO demo_svm_settings (setting_name, setting_value) VALUES
  (dbms_data_mining.svms_kernel_function, dbms_data_mining.svms_linear);
  insert into demo_svm_settings (setting_name, setting_value) VALUES
  (dbms_data_mining.prep_auto, dbms_data_mining.prep_auto_on);

END;
/

---------------------
-- CREATE A NEW MODEL
--
BEGIN
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => 'demo_class_svm',
    mining_function     => dbms_data_mining.classification,
    data_table_name     => 'HR_EMPLOYEE_ATTRITION',
    case_id_column_name => null,
    target_column_name  => 'attrition',
    settings_table_name => 'demo_svm_settings');
END;
/

select * from user_mining_models where model_name = 'DEMO_CLASS_SVM'

------------------------
-- DISPLAY MODEL DETAILS
--
-- The coefficient indicates the relative influence of a given
-- (attribute, value) pair on the target value. A negative
-- coefficient value indicates a negative influence.


SELECT setting_name, setting_value
  FROM user_mining_model_settings
 WHERE model_name = 'DEMO_CLASS_SVM'
ORDER BY setting_name;

SELECT D.class, A.attribute_name aname, A.attribute_value aval, A.coefficient coeff
  FROM TABLE(DBMS_DATA_MINING.GET_MODEL_DETAILS_SVM('SVMC_SH_Clas_sample')) D,
       TABLE(D.attribute_set) A
ORDER BY D.class, ABS(A.coefficient) DESC;
