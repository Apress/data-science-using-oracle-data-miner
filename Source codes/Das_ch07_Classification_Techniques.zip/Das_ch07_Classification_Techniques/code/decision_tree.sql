CREATE TABLE demo_dt_settings (
  setting_name  VARCHAR2(30),
  setting_value VARCHAR2(4000));
  
BEGIN       
  -- Populate settings table
  INSERT INTO demo_dt_settings VALUES
    (dbms_data_mining.algo_name, dbms_data_mining.algo_decision_tree);
  INSERT INTO demo_dt_settings VALUES
    (dbms_data_mining.tree_impurity_metric, 'TREE_IMPURITY_ENTROPY');
	
END;
/

---------------------
-- CREATE A NEW MODEL
--
-- Build a DT model
BEGIN
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => 'demo_class_dt',
    mining_function     => dbms_data_mining.classification,
    data_table_name     => 'HR_EMPLOYEE_ATTRITION',
    case_id_column_name => null,
    target_column_name  => 'attrition',
    settings_table_name => 'demo_dt_settings');
END;
/

-------------------------
-- DISPLAY MODEL SETTINGS
--

SELECT setting_name, setting_value
  FROM user_mining_model_settings
 WHERE model_name = 'DEMO_CLASS_DT'
ORDER BY setting_name;

SELECT 
 dbms_data_mining.get_model_details_xml('demo_class_dt') 
 AS DT_DETAILS
FROM dual;