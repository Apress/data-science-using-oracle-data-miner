select cust_id, rfm_recency, rfm_frequency, rfm_monetary,
       rfm_recency*100 + rfm_frequency*10 + rfm_monetary as rfm_combined
from
(select cust_id,
   ntile (5) over (order by last_purchase_date) as rfm_recency,
   ntile (5) over (order by count_purchases)    as rfm_frequency,
   ntile (5) over (order by total_amount)       as rfm_monetary
 from
 (select cust_id, 
         max(time_id)     as last_purchase_date,
         count(*)         as count_purchases,
         sum(amount_sold) as total_amount
  from "SALES_N$10001"
  group by cust_id)
)
order by 5 desc