
--Add a sequence to the XXCUST_IRIS_DATA table

create sequence iris_seq start with 1 increment by 1 nomaxvalue;

UPDATE XXCUST_IRIS_DATA
   SET ID = iris_seq.nextval;

COMMIT;

ALTER TABLE XXCUST_IRIS_DATA ADD CONSTRAINT pk_iris_data PRIMARY KEY(ID )

CREATE VIEW XXCUST_IRIS_DATA_V AS
SELECT ID,
       SEPAL_LENGTH,
	   SEPAL_WIDTH,
	   PETAL_LENGTH,
	   PETAL_WIDTH 
FROM  XXCUST_IRIS_DATA


select class petal_class,count(class) no_of_records from test_odm_cluster_results group by class
union
select to_char(clus_km_1_16_clid) petal_class,count(clus_km_1_16_clid) no_of_records from test_odm_cluster_results group by clus_km_1_16_clid

--- ODM PLSQL code

-- Create Settings tables to be used in model building
CREATE TABLE odm_km_settings (
   setting_name  VARCHAR2(30),
   setting_value VARCHAR2(4000));
 
-- Insert settings
SET SERVER OUTPUT ON;
BEGIN       
   INSERT INTO odm_km_settings (setting_name, setting_value) VALUES
   (dbms_data_mining.kmns_distance,dbms_data_mining.kmns_euclidean);

   INSERT INTO odm_km_settings (setting_name, setting_value) VALUES 
   (dbms_data_mining.prep_auto,dbms_data_mining.prep_auto_off);
   
   INSERT INTO odm_km_settings (setting_name, setting_value) VALUES 
   (dbms_data_mining.CLUS_NUM_CLUSTERS,3);
   -- Other examples of overrides are:
   -- (dbms_data_mining.kmns_iterations,3);
   -- (dbms_data_mining.kmns_block_growth,2);
   -- (dbms_data_mining.kmns_conv_tolerance,0.01);
   -- (dbms_data_mining.kmns_split_criterion,dbms_data_mining.kmns_variance);
   -- (dbms_data_mining.kmns_min_pct_attr_support,0.1);
   -- (dbms_data_mining.kmns_num_bins,10);
END;
/

---------------------
-- CREATE A NEW MODEL
--
BEGIN
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => 'KM_ODM_MODEL',
    mining_function     => dbms_data_mining.clustering,
    data_table_name     => 'XXCUST_IRIS_DATA_V',
    case_id_column_name => 'ID',
    settings_table_name => 'odm_km_settings');
END;
/

-- Check if model is created

select * from user_mining_models where model_name = 'KM_ODM_MODEL'

-- Check the data attributes used to create the model
SELECT attribute_name, attribute_type
  FROM user_mining_model_attributes
 WHERE model_name = 'KM_ODM_MODEL'
ORDER BY attribute_name;

-- Result Evaluation API

select DBMS_DATA_MINING.GET_MODEL_DETAILS_KM('KM_ODM_MODEL') from dual

--View the cluster rules

SELECT model.id rule_id,
         antecedent.attribute_name aname,
         antecedent.conditional_operator operator,
         NVL(antecedent.attribute_str_value,ROUND(antecedent.attribute_num_value,4)) value,
         model.rule.rule_support    support,
         model.rule.rule_confidence confidence
  FROM TABLE(DBMS_DATA_MINING.GET_MODEL_DETAILS_KM('KM_ODM_MODEL')) model,
        TABLE(model.rule.antecedent) antecedent,
        TABLE(model.child) chl
  where chl.id is null
ORDER BY model.id, support, confidence desc;
