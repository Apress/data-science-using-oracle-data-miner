library(ORE) 
ore.connect(user = "dmuser", sid = "ORCL", host = "localhost", password = "sibanjan123",port = 1521) 
ore.sync("DMUSER","XXCUST_IRIS_DATA",use.keys=TRUE)
a<-ore.get("XXCUST_IRIS_DATA",schema="DMUSER")
ore.ls()
km.iris<- ore.odmKMeans(~., a,num.centers=3, auto.data.prep=FALSE)
summary(km.iris)
rules(km.iris)
km.iris$name
ore.save(km.iris, name="km_ore_cluster_iris",overwrite=TRUE)
  
#PLSQL API for displaying the results. Run it from SQL client 
#Replace ORE$19_18 with your ORE model name

select DBMS_DATA_MINING.GET_MODEL_DETAILS_KM("ORE$19_18") from dual;
