SET SERVEROUTPUT ON;
BEGIN
dbms_data_mining.apply
        (model_name => 'CLUS_KM_1_8',
         data_table_name => 'CUST_TRANSACTION_NEW', 
         case_id_column_name => 'cust_id',
         result_table_name => 'CUST_SEGMENT_RESULTS'); 
END;
/