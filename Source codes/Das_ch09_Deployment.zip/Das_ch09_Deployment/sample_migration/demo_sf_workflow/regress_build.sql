
EXECUTE dbms_output.put_line('');
EXECUTE dbms_output.put_line('Regress Build node started: ' || SYSTIMESTAMP);
EXECUTE dbms_output.put_line('');

DECLARE
  v_caseid            VARCHAR2(30);
  v_target            VARCHAR2(30);
  v_input_data        VARCHAR2(30);
  v_build_data        VARCHAR2(30);
  v_test_data         VARCHAR2(30);
  v_apply_data        VARCHAR2(30);
  v_data_usage        VARCHAR2(30);
  v_build_setting     VARCHAR2(30);
  v_test_metric       VARCHAR2(30);
  v_lexer_name        VARCHAR2(30);
  v_auto_filter_name  VARCHAR2(30);
  v_stoplist_name     VARCHAR2(30);
  v_policy_name       VARCHAR2(30);
  v_residual_plot     VARCHAR2(30);
  v_rms_error         NUMBER;
  v_absolute_error    NUMBER;
  v_mean_actual       NUMBER;
  v_mean_predicted    NUMBER;
  v_predictive_conf   NUMBER;
  v_xlst              dbms_data_mining_transform.TRANSFORM_LIST;
  v_sql               CLOB;
  v_sql2              CLOB;
  v_user_session      VARCHAR2(30) := SYS_CONTEXT ('USERENV', 'SESSION_USER');
  v_drop              VARCHAR2(30) := '&DROP_EXISTING_OBJECTS';
  
  FUNCTION generateUniqueName RETURN VARCHAR2 IS
    v_uniqueName  VARCHAR2(30);
  BEGIN
    SELECT 'ODMR$'||TO_CHAR(SYSTIMESTAMP,'HH24_MI_SS_FF')||dbms_random.string(NULL, 7) INTO v_uniqueName FROM dual;
    RETURN v_uniqueName;
  END;
    
  FUNCTION getInputSource(p_nodeId VARCHAR2) RETURN VARCHAR2 IS
    v_output  VARCHAR2(30);
  BEGIN
    SELECT OUTPUT_NAME INTO v_output FROM "&WORKFLOW_OUTPUT" WHERE NODE_ID = p_nodeId AND COMMENTS = 'Output Data';
    RETURN v_output;
  END;

  FUNCTION getTextPolicy(p_nodeId VARCHAR2, p_column VARCHAR2 DEFAULT NULL) RETURN VARCHAR2 IS
    v_output  VARCHAR2(30);
  BEGIN
    IF (p_column IS NULL) THEN
      SELECT OUTPUT_NAME INTO v_output FROM "&WORKFLOW_OUTPUT" WHERE NODE_ID = p_nodeId AND OUTPUT_TYPE = 'POLICY' AND ADDITIONAL_INFO IS NULL;
    ELSE
      SELECT OUTPUT_NAME INTO v_output FROM "&WORKFLOW_OUTPUT" WHERE NODE_ID = p_nodeId AND OUTPUT_TYPE = 'POLICY' AND ADDITIONAL_INFO = 'Column='||p_column;
    END IF;
    RETURN v_output;
  END;

  PROCEDURE recordOutput(p_NODE_ID VARCHAR2, p_NODE_NAME VARCHAR2, p_NODE_TYPE VARCHAR2, 
                         p_MODEL_ID VARCHAR2, p_MODEL_NAME VARCHAR2, p_MODEL_TYPE VARCHAR2, 
                         p_OUTPUT_NAME VARCHAR2, p_OUTPUT_TYPE VARCHAR2, p_ADDITIONAL_INFO VARCHAR2, p_COMMENTS VARCHAR2) IS
  BEGIN
    INSERT INTO "&WORKFLOW_OUTPUT" VALUES (p_NODE_ID, p_NODE_NAME, p_NODE_TYPE, p_MODEL_ID, REPLACE(REPLACE(p_MODEL_NAME,'"',''), (v_user_session||'.'), ''), p_MODEL_TYPE, p_OUTPUT_NAME, p_OUTPUT_TYPE, p_ADDITIONAL_INFO, SYSTIMESTAMP, p_COMMENTS);
    COMMIT;
  END;

  PROCEDURE execSQL(p_sql CLOB) IS
    curid         INTEGER;
    ignoreid      INTEGER;    
  BEGIN
    curid := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(curid, p_sql, DBMS_SQL.NATIVE);
    ignoreid := DBMS_SQL.EXECUTE(curid);
    DBMS_SQL.CLOSE_CURSOR(curid);
  EXCEPTION WHEN OTHERS THEN
    IF DBMS_SQL.IS_OPEN(curid) THEN
      DBMS_SQL.CLOSE_CURSOR(curid);
    END IF;
    RAISE;
  END;

  FUNCTION formatErrorStack(
    p_node_name IN VARCHAR2,
    p_sqlerr        IN VARCHAR2,
    p_error_stack   IN VARCHAR2 ) RETURN VARCHAR2
  IS
  BEGIN
    RETURN SUBSTR('Error in ' || p_node_name || ': ' || CHR(13) || CHR(10) || p_sqlerr || 
                   CHR(13) || CHR(10) || p_error_stack, 1, 4000);
  END;

BEGIN
  -- input view
  v_caseid := 'ORDER_DATE';
  v_target := 'WATCH';
  
  v_input_data := generateUniqueName;
   
  v_sql := 
    'CREATE VIEW '||v_input_data||' AS SELECT /*+ NO_PARALLEL */ * FROM 
    ( 
      SELECT "'||v_caseid||'", 
        "FASHION_WEAR",
        "FURNITURE",
        "JEWELRY",
        "TOYS",
        "WATCH" 
      FROM '||getInputSource('10002')||' WHERE LENGTH(TRIM('||v_target||')) IS NOT NULL 
    )'; 
  execSQL(v_sql); 
   
  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', NULL, NULL, NULL, v_input_data, 'VIEW', NULL, 'Input Data'); 

  v_build_data := generateUniqueName; 
  v_sql :=  
    'CREATE VIEW '||v_build_data||' AS SELECT /*+ NO_PARALLEL */ * FROM 
    ( 
      SELECT * FROM (SELECT /*+ no_merge */ t.* FROM '||v_input_data||' t) 
      WHERE ORA_HASH('||v_caseid||', 99, 0) <= 60.0 
    )'; 
  execSQL(v_sql); 
  
  v_test_data := generateUniqueName; 
  v_sql := 
    'CREATE VIEW '||v_test_data||' AS SELECT /*+ NO_PARALLEL */ * FROM 
    ( 
      SELECT * FROM (SELECT /*+ no_merge */ t.* FROM '||v_input_data||' t) 
      WHERE ORA_HASH('||v_caseid||', 99, 0) > 60.0 
    )'; 
  execSQL(v_sql); 
  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', NULL, NULL, NULL, v_build_data, 'VIEW', NULL, 'Build Data');
  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', NULL, NULL, NULL, v_test_data, 'VIEW', NULL, 'Test Data');


  -- data usage view
  v_data_usage := generateUniqueName;
  
  v_sql := 
    'CREATE VIEW '||v_data_usage||' AS SELECT /*+ NO_PARALLEL */ "'||v_caseid||'", 
        "FASHION_WEAR",
        "FURNITURE",
        "JEWELRY",
        "TOYS",
        "WATCH" 
    FROM '||v_build_data;
  execSQL(v_sql);
  
  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', '10005', '&MODEL_1', 'Generalized Linear Model', v_data_usage, 'VIEW', NULL, 'Data Usage');
  v_xlst := dbms_data_mining_transform.TRANSFORM_LIST(); 

  -- build setting
  v_build_setting := generateUniqueName;
  execSQL('CREATE TABLE '||v_build_setting||' (SETTING_NAME VARCHAR2(30), SETTING_VALUE VARCHAR2(128))'); 
  execSQL('INSERT INTO '||v_build_setting||' VALUES ('''||DBMS_DATA_MINING.GLMS_CONF_LEVEL||''', 0.95)'); 
  execSQL('INSERT INTO '||v_build_setting||' VALUES ('''||DBMS_DATA_MINING.GLMS_VIF_FOR_RIDGE||''', ''GLMS_VIF_RIDGE_DISABLE'')'); 
  execSQL('INSERT INTO '||v_build_setting||' VALUES ('''||DBMS_DATA_MINING.ALGO_NAME||''', '''||DBMS_DATA_MINING.ALGO_GENERALIZED_LINEAR_MODEL||''')'); 
  execSQL('INSERT INTO '||v_build_setting||' VALUES ('''||DBMS_DATA_MINING.PREP_AUTO||''', '''||DBMS_DATA_MINING.PREP_AUTO_ON||''')'); 

  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', '10005', '&MODEL_1', 'Generalized Linear Model', v_build_setting, 'TABLE', NULL, 'Build Setting');

  -- model build
  IF (v_drop = 'TRUE') THEN -- delete any existing model?
    BEGIN
      DBMS_DATA_MINING.DROP_MODEL('&MODEL_1', TRUE);
    EXCEPTION WHEN OTHERS THEN
      NULL; -- ignore if no existing model to drop
    END;
  END IF;
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => '&MODEL_1',
    mining_function     => DBMS_DATA_MINING.REGRESSION,
    data_table_name     => v_data_usage,
    case_id_column_name => '"'||v_caseid||'"',
    target_column_name  => '"'||v_target||'"',
    settings_table_name => v_build_setting,
    xform_list          => v_xlst);
  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', '10005', '&MODEL_1', 'Generalized Linear Model', '&MODEL_1', 'MODEL', NULL, 'Model');

  -- apply result for test
  v_apply_data := generateUniqueName;
  execSQL('CREATE TABLE '||v_apply_data||' NOPARALLEL NOLOGGING AS SELECT /*+ NO_PARALLEL */ "'||v_caseid||'", PREDICTION(&MODEL_1 USING *) pred FROM '||v_test_data);
  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', '10005', '&MODEL_1', 'Generalized Linear Model', v_apply_data, 'TABLE', NULL, 'Apply Data');

  -- test metric
  v_test_metric := generateUniqueName;
  execSQL('CREATE TABLE '||v_test_metric||' (METRIC_NAME VARCHAR2(30), METRIC_VARCHAR_VALUE VARCHAR2(128), METRIC_NUM_VALUE NUMBER)');
  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', '10005', '&MODEL_1', 'Generalized Linear Model', v_test_metric, 'TABLE', NULL, 'Test Metric');

  execSQL('INSERT INTO '||v_test_metric||' (METRIC_NAME, METRIC_VARCHAR_VALUE) VALUES (''MODEL_NAME'', ''&MODEL_1'')');
  execSQL('INSERT INTO '||v_test_metric||' (METRIC_NAME, METRIC_VARCHAR_VALUE) VALUES (''MINING_FUNCTION'', ''REGRESSION'')');
  execSQL('INSERT INTO '||v_test_metric||' (METRIC_NAME, METRIC_VARCHAR_VALUE) VALUES (''TARGET_ATTRIBUTE'', '''||v_target||''')');

  -- 1. Root Mean Square Error - Sqrt(Mean((x - x')^2))
  v_sql := '
  SELECT SQRT(AVG(POWER((A.pred - (B."'||v_target||'")), 2))) rmse
    FROM '||v_apply_data||' A,
         '||v_test_data||' B
   WHERE A."'||v_caseid||'" = B."'||v_caseid||'"';
  EXECUTE IMMEDIATE v_sql INTO v_rms_error;
  execSQL('INSERT INTO '||v_test_metric||' (METRIC_NAME, METRIC_NUM_VALUE) VALUES (''MEAN_RMS_ERROR'', '||NVL(v_rms_error, 0)||')');

  -- 2. Mean Absolute Error - Mean(|(x - x')|)
  v_sql := '
  SELECT AVG(ABS(A.pred - B."'||v_target||'")) mae
    FROM '||v_apply_data||' A,
         '||v_test_data||' B
    WHERE A."'||v_caseid||'" = B."'||v_caseid||'"';
  EXECUTE IMMEDIATE v_sql INTO v_absolute_error;
  execSQL('INSERT INTO '||v_test_metric||' (METRIC_NAME, METRIC_NUM_VALUE) VALUES (''MEAN_ABSOLUTE_ERROR'', '||NVL(v_absolute_error, 0)||')');

  -- 3. Mean Actual Value
  v_sql := '
  SELECT AVG("'||v_target||'") as mean_actual_value
    FROM '||v_test_data;
  EXECUTE IMMEDIATE v_sql INTO v_mean_actual;
  execSQL('INSERT INTO '||v_test_metric||' (METRIC_NAME, METRIC_NUM_VALUE) VALUES (''MEAN_ACTUAL_VALUE'', '||NVL(v_mean_actual, 0)||')');

  -- 4. Mean Predicted Value
  v_sql := '
  SELECT
    AVG(PREDICTION(&MODEL_1 using *)) as mean_predicted_value
  FROM '||v_test_data;
  EXECUTE IMMEDIATE v_sql INTO v_mean_predicted;
  execSQL('INSERT INTO '||v_test_metric||' (METRIC_NAME, METRIC_NUM_VALUE) VALUES (''MEAN_PREDICATED_VALUE'', '||NVL(v_mean_predicted, 0)||')');

  -- Overall predictive Confidence = 1 - ((Error of Predict)/(Error of naive model))
  v_sql := '
  WITH
  a as
  (SELECT SQRT(AVG(POWER((A.pred - (B."'||v_target||'")), 2))) rmse
    FROM '||v_apply_data||' A,
         '||v_test_data||' B
   WHERE A."'||v_caseid||'" = B."'||v_caseid||'")
  ,
  b as
  (SELECT SQRT(count(*)/(count(*)-1) * variance("'||v_target||'")) ne
    FROM '||v_test_data||')
  SELECT (1 - a.rmse / GREATEST(0.0001, b.ne)) * 100 FROM a, b';
  EXECUTE IMMEDIATE v_sql INTO v_predictive_conf;
  v_predictive_conf := GREATEST(0, v_predictive_conf); -- cap the value >= 0
  execSQL('INSERT INTO '||v_test_metric||' (METRIC_NAME, METRIC_NUM_VALUE) VALUES (''PREDICTIVE_CONFIDENCE'', '||NVL(v_predictive_conf, 0)||')');

  -- Residual plot 
  v_residual_plot := generateUniqueName; 
  v_sql :=  'CREATE TABLE '||v_residual_plot||' NOPARALLEL NOLOGGING AS 
    SELECT /*+ NO_PARALLEL */ * 
      FROM (SELECT 
            A.'||v_caseid||' CASEID, 
            (B."'||v_target||'") TARGET, 
            A.pred PREDICTION, 
            ((B."'||v_target||'") - A.pred) RESIDUAL 
              FROM '||v_apply_data||' A, 
                   '||v_test_data||' B 
             WHERE A.'||v_caseid||' = B.'||v_caseid||' 
            ORDER BY A.pred ASC) WHERE RESIDUAL IS NOT NULL'; 
  execSQL(v_sql); 
  recordOutput('10006', 'Regress Build', 'RegressionBuildNode', '10005', '&MODEL_1', 'Generalized Linear Model', v_residual_plot, 'TABLE', NULL, 'Residual Plot'); 



EXCEPTION WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20999, formatErrorStack('Regress Build', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()));
END;
/
EXECUTE dbms_output.put_line('');
EXECUTE dbms_output.put_line('Regress Build node completed: ' || SYSTIMESTAMP);
EXECUTE dbms_output.put_line('');
