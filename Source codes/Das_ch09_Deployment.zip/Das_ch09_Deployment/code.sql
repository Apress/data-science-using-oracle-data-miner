grant create any directory to dmuser;
CREATE OR REPLACE DIRECTORY dmdir AS 'F:\sample_mig\oracle';
BEGIN
DBMS_DATA_MINING.EXPORT_MODEL ('CLAS_DT_1_14.dmp','dmdir','name =''CLAS_DT_1_14''');
END;
begin
DBMS_DATA_MINING.EXPORT_MODEL ( 'multi_model_out', 'dmdir','name in (''CLAS_SVM_1_14'', ''CLAS_GLM_1_14'')');
end;
BEGIN 
DBMS_DATA_MINING.IMPORT_MODEL('CLAS_DT_1_1401.dmp', 'dmdir'); 
END;
DBMS_DATA_MINING.RENAME_MODEL('DEMO_CLASS_DT','CUST_CHURN_MODEL');
DBMS_DATA_MINING.DROP_MODEL('CHURN_MODEL');
BEGIN
DBMS_DATA_MINING.IMPORT_MODEL ('LinearRegression',
                                 XMLType(bfilename ('DMDIR', 'linearRegression.xml'), 
                                nls_charset_id ('AL32UTF8') )) ;
END;
SELECT  dbms_data_mining.get_model_details_xml('demo_class_dt')  AS DT_DETAILS from dual;