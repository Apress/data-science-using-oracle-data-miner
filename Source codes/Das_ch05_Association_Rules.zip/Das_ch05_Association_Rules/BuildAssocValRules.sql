begin
sys.rqScriptDrop('BuildAssocValRules');
sys.rqScriptCreate('BuildAssocValRules',
'function(dat, min.support=0.01, min.conf = 0.1, max.run.len=5)
{
library(ORE)
library(arules)
dataODF <- as.ore.frame(dat)
assoc.mod <- ore.odmAssocRules(~., dataODF,case.id.column= "TRANSACTION_ID",item.id.column= "ITEM", item.value.column="PURCHASE_QTY",min.support= min.support,min.confidence= min.conf ,max.rule.length = max.run.len)
rules <-rules(assoc.mod)
rules <-ore.pull(rules)
as(rules, "data.frame")
}');
END;