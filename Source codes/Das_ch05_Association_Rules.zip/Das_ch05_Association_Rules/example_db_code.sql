set serveroutput on
CREATE TABLE ar_settings_demo (
  setting_name  VARCHAR2(30),
  setting_value VARCHAR2(4000));
/
BEGIN       
-- Inserts the default overriden value for minimum support
  INSERT INTO ar_settings_demo VALUES
  (dbms_data_mining.asso_min_support,0.1);
-- Inserts the default overriden value for minimum confidence
  INSERT INTO ar_settings_demo VALUES
  (dbms_data_mining.asso_min_confidence,0.1);
-- Inserts the default overriden value for maximum rule length
  INSERT INTO ar_settings_demo VALUES
  (dbms_data_mining.asso_max_rule_length,3);
-- Inserts the Item ID
  INSERT INTO ar_settings_demo VALUES
  (dbms_data_mining.odms_item_id_column_name, 'PRODUCT_ID');
  COMMIT;
END;
/
BEGIN
  DBMS_DATA_MINING.CREATE_MODEL(
    model_name          => 'DEMO_AR_MODEL',
    mining_function     => DBMS_DATA_MINING.ASSOCIATION,
    data_table_name     => 'DEMO_AR_RULES_DATA',
    case_id_column_name => 'TRANS_ID',
    settings_table_name => 'ar_settings_demo'
    );
END;
/

SELECT setting_name, setting_value
  FROM user_mining_model_settings
 WHERE model_name = 'DEMO_AR_MODEL'
ORDER BY setting_name;


SELECT a.attribute_subname antecedent,
       c.attribute_subname consequent,
       rule_support support,
       rule_confidence confidence,
       rule_lift lift
  FROM TABLE(DBMS_DATA_MINING.GET_ASSOCIATION_RULES('DEMO_AR_MODEL', 10)) T,
       TABLE(T.consequent) C,
       TABLE(T.antecedent) A
 ORDER BY lift DESC, support DESC, support DESC;

