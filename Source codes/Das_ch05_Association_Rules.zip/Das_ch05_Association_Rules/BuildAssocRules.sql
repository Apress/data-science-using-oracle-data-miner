begin
-- sys.rqScriptDrop drops the existing ORE script with the same name. This script has to be commented out on the first run
sys.rqScriptDrop('BuildAssocRules');
-- sys. rqScriptCreate to create a new ORE script
sys.rqScriptCreate('BuildAssocRules',
'function(dat, min.support=0.01, min.conf = 0.1, max.run.len=5)
{
library(ORE)
library(arules)
dataODF <- as.ore.frame(dat)
# ore.odmAssocRules is the ORE equivalent function for ODM association rules. The model and 
# algorithims settings are similar to that described in above sections
assoc.mod <- ore.odmAssocRules(~., dataODF,case.id.column= "TRANSACTION_ID",item.id.column= "ITEM", min.support= min.support,min.confidence= min.conf ,max.rule.length = max.run.len)
rules <-rules(assoc.mod)
rules <-ore.pull(rules)
#Converts the rules to a data frame to be recognized by rqTableEval as individual columns and 
#inserted into the results table
as(rules, "data.frame")
}');
END;
