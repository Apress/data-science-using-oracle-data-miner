CREATE OR REPLACE PACKAGE DEMO_ASSOC_MODELS_PUB AS

 G_PACKAGE_NAME Varchar2(30) := 'DEMO_ASSOC_MODELS_PUB';
 
    /*--------------------------------------------------------------------------------------------
  -- PROCEDURE                                                                                  -- 
  --    Main                                                                                    --
  --                                                                                            --
  -- DESCRIPTION                                                                                --
  --   * Driving procedure to build Association Rules Model.                                    --
  --                                                                                            --
  -- HISTORY:                                                                                   --
  --   19/06/2016           Sibanjan Das           Created                                      --
  ----------------------------------------------------------------------------------------------*/
  Procedure MAIN(p_model_type In Varchar2);
  
  /*--------------------------------------------------------------------------------------
  -- PROCEDURE                                                                          --
  --    Build_Assoc_Val_Model                                                           --
  --                                                                                    --
  -- DESCRIPTION                                                                        --
  --   * Builds Association Rules Model with value parameter. This procedure also       --
  --    demonstrates the use of rqTableEval function                                    --
  --                                                                                    --
  --                                                                                    --
  -- HISTORY:                                                                           --
  --   19/06/2016           Sibanjan Das           Created                              --
  ----------------------------------------------------------------------------------------*/
  Procedure Build_Assoc_Val_Model(
      p_data_view           In Varchar2,
      x_return_status       Out Nocopy Varchar2,
      x_return_msg          OUT NOCOPY VARCHAR2
   );
   
   /*---------------------------------------------------------------------------------------------
  -- PROCEDURE                                                                                  -- 
  --    Build_Assoc_Model                                                                       --
  --                                                                                            --
  -- DESCRIPTION                                                                                --
  --   * Builds Association Rules Model. This procedure demonstrates the use of rqEval function --                                                 --
  --                                                                                            --
  -- HISTORY:                                                                                   --
  --   19/06/2016           Sibanjan Das           Created                                      --
  ----------------------------------------------------------------------------------------------*/
  Procedure Build_Assoc_Model(
      p_data_view           In Varchar2,
      x_return_status       Out Nocopy Varchar2,
      x_return_msg          OUT NOCOPY VARCHAR2
   );
 
END DEMO_ASSOC_MODELS_PUB;
/

CREATE OR REPLACE PACKAGE BODY DEMO_ASSOC_MODELS_PUB AS

    PROCEDURE LOG_MESSAGE(p_message IN VARCHAR2) 
    IS
    BEGIN
       DBMS_OUTPUT.PUT_LINE(p_message);
    END LOG_MESSAGE;

  /*--------------------------------------------------------------------------------------
  -- PROCEDURE                                                                          --
  --    Build_Assoc_Val_Model                                                           --
  --                                                                                    --
  -- DESCRIPTION                                                                        --
  --   * Builds Association Rules Model with value parameter. This procedure also       --
  --    demonstrates the use of rqTableEval function                                    --
  --                                                                                    --
  --                                                                                    --
  -- HISTORY:                                                                           --
  --   19/06/2016           Sibanjan Das           Created                              --
  ----------------------------------------------------------------------------------------*/

  Procedure Build_Assoc_Val_Model(
      p_data_view           In Varchar2,
      x_return_status       Out Nocopy Varchar2,
      x_return_msg          OUT NOCOPY VARCHAR2
   )
    IS
         l_method_name       VARCHAR2(30):= 'Build_Assoc_Val_Model';
         l_output_table      VARCHAR(30) := 'DEMO_ASSOC_RULES_RES';
         l_insert_sql        VARCHAR2(32767);
         l_last_update_date  DATE    := SYSDATE;
         l_last_updated_by   NUMBER  := -1;
         l_creation_date     DATE    := SYSDATE;
         l_created_by        NUMBER  := -1;
		 l_mining_function   VARCHAR2(30) := 'BuildAssocValRules';
         
    BEGIN
    
        LOG_MESSAGE('START OF '||G_PACKAGE_NAME||'.'||l_method_name);
	
		-- Invokes ORE function BuildAssocValRules and insert the results into table DEMO_ASSOC_RULES_RES
             
        l_insert_sql := 'INSERT INTO '||l_output_table||'(RESULT_ID,MODEL_TYPE,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,CREATED_BY,RULES,SUPPORT,CONFIDENCE,LIFT) '||' SELECT DEMO_ASSOC_RULES_S.NEXTVAL'||',''VALUE'','''||l_last_update_date||''','||l_last_updated_by||','''||l_creation_date||''','||l_created_by||',rqtab.* FROM table(rqTableEval(cursor(SELECT * FROM '||p_data_view||'),cursor(SELECT 1 as "ore.connect" FROM dual),'' select cast(''''a'''' as VARCHAR2(4000)) "RULES",1 "SUPPORT", 1 "CONFIDENCE", 1 "LIFT" from dual'','''||l_mining_function||''')) rqtab';

        LOG_MESSAGE(G_PACKAGE_NAME||'.'||l_method_name||' Dynamic insert into '||l_output_table||' Query: '||l_insert_sql);
   
        EXECUTE IMMEDIATE l_insert_sql;
        
        COMMIT;
        
        x_return_status :=  'S';
        
        LOG_MESSAGE('END OF '||G_PACKAGE_NAME||'.'||l_method_name);
        
    EXCEPTION WHEN OTHERS THEN
		x_return_status :=  'E';
		x_return_msg := G_PACKAGE_NAME||'.'||l_method_name||': '||SQLERRM;
    
    END Build_Assoc_Val_Model;
 
  /*---------------------------------------------------------------------------------------------
  -- PROCEDURE                                                                                  -- 
  --    Build_Assoc_Model                                                                       --
  --                                                                                            --
  -- DESCRIPTION                                                                                --
  --   * Builds Association Rules Model. This procedure demonstrates the use of rqEval function --                                                 --
  --                                                                                            --
  -- HISTORY:                                                                                   --
  --   19/06/2016           Sibanjan Das           Created                                      --
  ----------------------------------------------------------------------------------------------*/
  Procedure Build_Assoc_Model(
      p_data_view           In Varchar2,
      x_return_status       Out Nocopy Varchar2,
      x_return_msg          OUT NOCOPY VARCHAR2
   ) IS
         l_method_name       VARCHAR2(30):= 'Build_Assoc_Model';
         l_output_table      VARCHAR(30) := 'DEMO_ASSOC_RULES_RES';
         l_insert_sql        VARCHAR2(32767);
         l_last_update_date  DATE    := SYSDATE;
         l_last_updated_by   NUMBER  := -1;
         l_creation_date     DATE    := SYSDATE;
         l_created_by        NUMBER  := -1;
		 l_mining_function   VARCHAR2(30) := 'BuildAssocRules';
         
    BEGIN
    
        LOG_MESSAGE('START OF '||G_PACKAGE_NAME||'.'||l_method_name);
		
	-- Invokes ORE function BuildAssocRules and insert the results into table DEMO_ASSOC_RULES_RES
        
       l_insert_sql := 'INSERT INTO '||l_output_table||'(RESULT_ID,MODEL_TYPE,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,CREATED_BY,RULES,SUPPORT,CONFIDENCE,LIFT) '||' SELECT DEMO_ASSOC_RULES_S.NEXTVAL'||',''EXISTENCE'','''||l_last_update_date||''','||l_last_updated_by||','''||l_creation_date||''','||l_created_by||',rqtab.* FROM table(rqTableEval(cursor(SELECT * FROM '||p_data_view||'),cursor(SELECT 1 as "ore.connect" FROM dual),'' select cast(''''a'''' as VARCHAR2(4000)) "RULES",1 "SUPPORT", 1 "CONFIDENCE", 1 "LIFT" from dual'','''||l_mining_function||''')) rqtab';

        LOG_MESSAGE(G_PACKAGE_NAME||'.'||l_method_name||' Dynamic insert into '||l_output_table||' Query: '||l_insert_sql);
   
        EXECUTE IMMEDIATE l_insert_sql;
        
        COMMIT;
        
        x_return_status :=  'S';
        
        LOG_MESSAGE('END OF '||G_PACKAGE_NAME||'.'||l_method_name);
        
    EXCEPTION WHEN OTHERS THEN
		x_return_status :=  'E';
		x_return_msg := G_PACKAGE_NAME||'.'||l_method_name||': '||SQLERRM;
      END Build_Assoc_Model;
    /*--------------------------------------------------------------------------------------------
  -- PROCEDURE                                                                                  -- 
  --    Main                                                                                    --
  --                                                                                            --
  -- DESCRIPTION                                                                                --
  --   * Driving procedure to build Association Rules Model.                                    --
  --                                                                                            --
  -- HISTORY:                                                                                   --
  --   19/06/2016           Sibanjan Das           Created                                      --
  ----------------------------------------------------------------------------------------------*/	  
	Procedure MAIN(p_model_type In Varchar2)
	IS
	    l_method_name   VARCHAR2(30):= 'MAIN';
		l_data_view     VARCHAR2(200);
		l_return_status VARCHAR2(10);
		l_return_msg    VARCHAR2(4000);
	BEGIN
		
		LOG_MESSAGE('Start of '||G_PACKAGE_NAME||'.'||l_method_name);
	-- Assign the view name to the l_data_view variable	
		l_data_view :='DEMO_ASSOC_PUR_V';
	
	-- Condition to check model_type: Value/Existence
		IF p_model_type='VALUE' then
	
	-- Invoke the Build_Assoc_Val_Model for value based model
		   Build_Assoc_Val_Model(p_data_view => l_data_view,
			                   x_return_status => l_return_status,
							   x_return_msg    => l_return_msg);
		ELSE
    -- Invoke the Build_Assoc_Model for existence based model
		    Build_Assoc_Model(p_data_view => l_data_view,
			                   x_return_status => l_return_status,
							   x_return_msg    => l_return_msg);
	    END IF;
	-- Check the return status
        IF l_return_status='S' then
		   LOG_MESSAGE('Rules were generated successfully and stored in database');
		ELSE
		   LOG_MESSAGE('Unsuccessful. Please check log or debug the code. The error message was '||l_return_msg);
	    END IF;
		
   		LOG_MESSAGE('End of '||G_PACKAGE_NAME||'.'||l_method_name);
	
	END MAIN;
 END DEMO_ASSOC_MODELS_PUB;
 /