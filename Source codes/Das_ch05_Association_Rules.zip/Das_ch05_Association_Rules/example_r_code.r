library(ORE)
library(arules)

if (!ore.is.connected()) # Check if client is already connected to R
ore.connect("dmuser", "orcl","localhost", "sibanjan123", all=TRUE)

assoc_df <- read.csv("C:/Users/Admin/Dropbox/analytics_book/chapter-5/example_data.csv")
names(assoc_df)<-c("TRANS_ID","PRODUCT_ID")  # Convert to uppercase so that API recognizes it as a table column name
ore.assoc_df <-ore.push(assoc_df)
ar.mod <-ore.odmAssocRules(~., ore.assoc_df, case.id.column= "TRANS_ID",item.id.column= "PRODUCT_ID", min.support= 0.5, min.confidence= 0.7,max.rule.length = 3)
itemsets<-itemsets(ar.mod)
itemsets
rules <-rules(ar.mod)
#Subset rules with item P04
sub.rules<-subset(rules, min.confidence=0.7, rhs=list("P04"))
sub.rules
# Convert the rules to the rules object of arulespackage
rules.arules<-ore.pull(rules)
inspect(rules.arules)

