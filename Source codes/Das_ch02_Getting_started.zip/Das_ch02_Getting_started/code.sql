--A sample code to illustrate the capabilities of this package
DECLARE
summary_values dbms_stat_funcs.SummaryType;
significance number;
BEGIN
dbms_stat_funcs.summary(p_ownername => 'APPS'
,p_tablename => 'TEST_PROD_SALES'
,p_columnname => 'revenue'
,p_sigma_value => 3
,s => summary_values);
dbms_output.put_line('*******'); 
dbms_output.put_line('Summary statistics of revenue column in TEST_PROD_SALES table:');
dbms_output.put_line('*******');
dbms_output.put_line('Number of records : '||summary_values.count);
dbms_output.put_line('Minimum Value : '||summary_values.min);
dbms_output.put_line('Maximum Value : '||summary_values.max);
dbms_output.put_line('Variance : '||round(summary_values.variance));
dbms_output.put_line('Stddev : '||round(summary_values.stddev));
dbms_output.put_line('Mean : '||summary_values.mean);
dbms_output.put_line('Mode : '||summary_values.cmode(1));
dbms_output.put_line('Median : '||summary_values.median);
dbms_output.put_line('*******');
dbms_output.put_line('Quantiles');
dbms_output.put_line('*******');
dbms_output.put_line('1st Quantile : '||summary_values.quantile_5);
dbms_output.put_line('2nd Quantile : '||summary_values.quantile_25);
dbms_output.put_line('3rd Quantile : '||summary_values.quantile_75);
dbms_output.put_line('4th Quantile : '||summary_values.quantile_95);
dbms_output.put_line('*******');
dbms_output.put_line('Extreme Count : '||summary_values.extreme_values.count);
dbms_output.put_line('Top Five Values :   '||summary_values.top_5_values(1)||','||summary_values.top_5_values(2)||','||summary_values.top_5_values(3)||','||summary_values.top_5_values(4)||','||summary_values.top_5_values(5));
dbms_output.put_line('Bottom Five Values : '||summary_values.bottom_5_values(5)||','||summary_values.bottom_5_values(4)||','||summary_values.bottom_5_values(3)||','||summary_values.bottom_5_values(4)||','||summary_values.bottom_5_values(5));
dbms_output.put_line('*******');
dbms_output.put_line('Normality Test');
dbms_output.put_line('*******');
dbms_stat_funcs.normal_dist_fit(ownername => 'APPS' 
,tablename => 'TEST_PROD_SALES'
,columnname => 'revenue'
,test_type => 'SHAPIRO_WILKS' 
,mean => summary_values.mean 
,stdev => summary_values.stddev 
,sig => significance);
dbms_output.put_line('Significance : '||significance); 
END;

select product_line,avg(revenue) 
from TEST_PROD_SALES
group by product_line;

select order_method_type, max(revenue)
from TEST_PROD_SALES
group by order_method_type;

select order_method_type, min(revenue)
from TEST_PROD_SALES
group by order_method_type;

SELECT product_line, sum(revenue), CUME_DIST() 
OVER ( ORDER BY sum(revenue)) AS cume_dist
FROM TEST_PROD_SALES
WHERE quarter = 'Q1 2012'
group by product_line;

SELECT quarter, product_line,FIRST_VALUE(product_line)
OVER ( ORDER BY tot_revenue ASC ROWS UNBOUNDED PRECEDING) AS unprofitable_product_line,tot_revenue revenue
FROM (select quarter, product_line,sum(revenue) tot_revenue from TEST_PROD_SALES where quarter = 'Q1 2012' group by quarter,product_line)
ORDER BY product_line,revenue;

SELECT quarter, product_line,LAST_VALUE(product_line)
OVER (ORDER BY tot_revenue ASC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS profitable_product_line,tot_revenue revenue
FROM (select quarter, product_line,sum(revenue) tot_revenue from TEST_PROD_SALES where quarter = 'Q1 2012' group by quarter,product_line)
ORDER BY product_line,revenue;

SELECT product_line,
sum(revenue),
RANK() OVER (order by sum(revenue) DESC) "rank"
FROM TEST_PROD_SALES
group by product_line;

SELECT product_line,product,
DENSE_RANK() OVER (order by revenue DESC) "rank"
FROM TEST_PROD_SALES
where quarter = 'Q1 2012';

select VARIANCE(revenue), STDDEV(revenue) 
from TEST_PROD_SALES;

select corr_s(revenue,gross_margin) from TEST_PROD_SALES;

SELECT product_line,AVG(revenue) group_mean,
STATS_T_TEST_ONE(revenue, 4000, 'STATISTIC') t_observed
FROM TEST_PROD_SALES
group by product_line;

SELECT product, revenue, width_bucket(revenue,0,814437.11,10) 
AS bucket FROM TEST_PROD_SALES
where quarter = 'Q1 2012'
and product = 'Star Lite';

SELECT product, sum(revenue), NTILE(10) OVER (ORDER BY sum(revenue) DESC) 
AS quartile FROM TEST_PROD_SALES
where quarter = 'Q1 2012'group by product;

SELECT product_line, 
SUM(revenue) monthly_sales,
SUM(SUM(revenue)) OVER (ORDER BY product_line
ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) running_total
FROM TEST_PROD_SALES
GROUP BY product_line
ORDER BY product_line;

SELECT quarter,
sum(revenue) current_revenue,
LAG(sum(revenue), 1, 0) OVER (ORDER BY sum(revenue)) AS revenue_prev,
sum(revenue) - LAG(sum(revenue), 1, 0) OVER (ORDER BY sum(revenue)) AS revenue_diff
FROM TEST_PROD_SALES
group by quarter
order by quarter desc;


SELECT quarter,
sum(revenue) AS current_revenue,
LEAD(sum(revenue), 1, 0) OVER (ORDER BY sum(revenue)) AS next_revenue,
LEAD(sum(revenue), 1, 0) OVER (ORDER BY sum(revenue))-sum(revenue) AS revenue_difference
FROM TEST_PROD_SALES
where product_line='Outdoor Protection'
group by quarter
order by quarter desc;

SELECT *
FROM (SELECT product_line, quantity
FROM TEST_PROD_SALES)
PIVOT (SUM(quantity) AS sum_quantity FOR (product_line) IN ('Outdoor Protection' AS Outdoor_Protection, 'Golf Equipment' AS Golf_Equipment, 'Camping Equipment' AS Camping_Equipment
,'Mountaineering Equipment' as Mountaineering_Equipment,'Personal Accessories' as Personal_Accessories));


CREATE TABLE TEST_PROD_QUANTITY (
id NUMBER,
product_line_outdoor NUMBER,
product_code_Golf NUMBER,
product_code_Camping NUMBER
);

INSERT INTO TEST_PROD_QUANTITY VALUES (1, 5404, 3177, 748);
INSERT INTO TEST_PROD_QUANTITY VALUES (2, 114, 304, 321);
INSERT INTO TEST_PROD_QUANTITY VALUES (3, 321, 828, 992);
INSERT INTO TEST_PROD_QUANTITY VALUES (4, 159, 517, 1502);
COMMIT;


SELECT *
FROM   TEST_PROD_QUANTITY 
UNPIVOT (quantity FOR product_line IN (product_line_outdoor AS 'Outdoor Protection', product_code_Golf AS 'Golf Equipment', product_code_Camping AS 'Camping Equipment'));


